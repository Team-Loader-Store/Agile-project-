# Loader Store Management — Parts Fitment

Python standard-library demonstration of the sales employee user story.

## Run

```bash
python app.py
```

Open http://localhost:8000 and select make, model, and optionally year.

## Tests

```bash
python -m unittest -v
```

## Acceptance criteria

- Make/model/year filter shows only compatible parts; year can be omitted.
- Results show stock, price and supported year range.
- Add to invoice updates an in-memory demo invoice and checks available stock.

## Integration notes

This is a standalone demo, **not** a production integration. Replace the sample `PARTS` catalog with database records and replace the in-memory `INVOICE` with your project's invoice service. In production, use POST + CSRF protection for invoice changes, persist invoice lines, and re-check compatibility and stock server-side at checkout. This demo uses GET to simplify local testing and must not be deployed as-is.

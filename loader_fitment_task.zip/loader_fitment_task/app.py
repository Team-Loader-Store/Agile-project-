"""Run: python app.py. Local demo UI using Python's standard library."""
from decimal import Decimal
from html import escape
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import parse_qs, urlparse
from loader_fitment import Loader, Part, Invoice, compatible_parts, loader_options

# Demo catalog: replace with your project's database records.
PARTS = [
    Part('CAT-001', 'Hydraulic Filter', Decimal('450.00'), 12, 'Caterpillar', '950H', 2006, 2012),
    Part('CAT-002', 'Brake Pad', Decimal('850.00'), 4, 'Caterpillar', '950H', 2008, 2014),
    Part('CAT-003', 'Oil Filter', Decimal('250.00'), 8, 'Caterpillar', '966H', 2006, 2013),
    Part('VOL-001', 'Air Filter', Decimal('500.00'), 0, 'Volvo', 'L120F', 2007, 2014),
]
INVOICE = Invoice()


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        params = parse_qs(urlparse(self.path).query)
        make = params.get('make', [''])[0]
        model = params.get('model', [''])[0]
        year_text = params.get('year', [''])[0]
        message = ''
        try:
            year = int(year_text) if year_text else None
            if year is not None and not 1900 <= year <= 2100:
                raise ValueError('Invalid year')
            selected = compatible_parts(PARTS, Loader(make, model, year)) if make and model else []
            if params.get('add'):
                sku = params['add'][0]
                part = next((p for p in selected if p.sku == sku), None)
                if part is None:
                    raise ValueError('Part is not compatible with the selected loader')
                INVOICE.add_part(part)
                message = f'Added {part.name} to invoice'
        except ValueError as error:
            selected = []
            message = str(error)
        options = loader_options(PARTS)
        makes = ''.join(f'<option value="{escape(m)}" {"selected" if m == make else ""}>{escape(m)}</option>' for m in options)
        models = ''.join(f'<option value="{escape(m)}" {"selected" if m == model else ""}>{escape(m)}</option>' for m in options.get(make, {}))
        years = sorted(options.get(make, {}).get(model, []))
        year_options = ''.join(f'<option value="{y}" {"selected" if str(y) == year_text else ""}>{y}</option>' for y in years)
        rows = ''.join(f'<tr><td>{escape(p.sku)}</td><td>{escape(p.name)}</td><td>{p.stock}</td><td>{p.price:.2f}</td><td>{p.year_from}–{p.year_to}</td><td><a href="?make={escape(make)}&model={escape(model)}&year={escape(year_text)}&add={escape(p.sku)}">Add to invoice</a></td></tr>' for p in selected)
        html = f'''<!doctype html><html><head><meta charset="utf-8"><title>Loader Parts Fitment</title><style>body{{font:16px Arial;max-width:1000px;margin:40px auto;padding:0 20px}}select,button{{padding:10px;margin:5px}}table{{border-collapse:collapse;width:100%}}td,th{{border:1px solid #ddd;padding:12px;text-align:left}}th{{background:#eee}}</style></head><body><h1>Loader Parts Fitment</h1><form method="get"><label>Make <select name="make" onchange="this.form.submit()"><option value="">Choose make</option>{makes}</select></label><label>Model <select name="model" onchange="this.form.submit()"><option value="">Choose model</option>{models}</select></label><label>Year (optional) <select name="year"><option value="">Any year</option>{year_options}</select></label><button type="submit">Find parts</button></form><p>{escape(message)}</p><table><tr><th>SKU</th><th>Part</th><th>Stock</th><th>Price</th><th>Fitting years</th><th>Action</th></tr>{rows or '<tr><td colspan="6">No matching parts (or select make and model).</td></tr>'}</table><h3>Invoice items: {sum(INVOICE.items.values())}</h3><p>Demo only: invoice is held in memory and resets on restart.</p></body></html>'''
        payload = html.encode('utf-8')
        self.send_response(200)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.send_header('Content-Length', str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)


if __name__ == '__main__':
    print('Open http://localhost:8000')
    HTTPServer(('127.0.0.1', 8000), Handler).serve_forever()

"""Loader parts compatibility and invoice logic (standard library only)."""
from dataclasses import dataclass, field
from decimal import Decimal


@dataclass(frozen=True)
class Loader:
    make: str
    model: str
    year: int | None = None


@dataclass(frozen=True)
class Part:
    sku: str
    name: str
    price: Decimal
    stock: int
    make: str
    model: str
    year_from: int
    year_to: int

    def fits(self, loader: Loader) -> bool:
        return (self.make.casefold() == loader.make.casefold()
                and self.model.casefold() == loader.model.casefold()
                and (loader.year is None or self.year_from <= loader.year <= self.year_to))


@dataclass
class Invoice:
    items: dict[str, int] = field(default_factory=dict)

    def add_part(self, part: Part, quantity: int = 1) -> None:
        if not isinstance(quantity, int) or isinstance(quantity, bool) or quantity <= 0:
            raise ValueError('Quantity must be a positive integer')
        if self.items.get(part.sku, 0) + quantity > part.stock:
            raise ValueError('Insufficient stock')
        self.items[part.sku] = self.items.get(part.sku, 0) + quantity


def compatible_parts(parts: list[Part], loader: Loader) -> list[Part]:
    if not loader.make.strip() or not loader.model.strip():
        raise ValueError('Make and model are required')
    return [part for part in parts if part.fits(loader)]


def loader_options(parts: list[Part]) -> dict[str, dict[str, list[int]]]:
    options: dict[str, dict[str, set[int]]] = {}
    for part in parts:
        years = options.setdefault(part.make, {}).setdefault(part.model, set())
        years.update(range(part.year_from, part.year_to + 1))
    return {make: {model: sorted(years) for model, years in models.items()}
            for make, models in options.items()}

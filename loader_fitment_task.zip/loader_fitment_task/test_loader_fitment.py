import unittest
from decimal import Decimal
from loader_fitment import Loader, Part, Invoice, compatible_parts, loader_options

P = Part('A', 'Filter', Decimal('50'), 2, 'CAT', '950H', 2010, 2015)

class FitmentTests(unittest.TestCase):
    def test_make_model_year(self):
        self.assertEqual(compatible_parts([P], Loader('cat', '950h', 2012)), [P])
        self.assertEqual(compatible_parts([P], Loader('CAT', '950H', 2016)), [])
        self.assertEqual(compatible_parts([P], Loader('Volvo', '950H')), [])
    def test_optional_year(self):
        self.assertEqual(compatible_parts([P], Loader('CAT', '950H')), [P])
    def test_options(self):
        self.assertEqual(loader_options([P])['CAT']['950H'], list(range(2010, 2016)))
    def test_invoice_stock(self):
        invoice = Invoice()
        invoice.add_part(P, 2)
        with self.assertRaises(ValueError): invoice.add_part(P)
    def test_invalid_quantity(self):
        with self.assertRaises(ValueError): Invoice().add_part(P, 0)

if __name__ == '__main__':
    unittest.main()
